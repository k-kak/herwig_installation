
MODEL_OPTIONS = {}

__all__ = ["MODEL_OPTIONS"]
