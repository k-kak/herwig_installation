#!/usr/bin/python
# vim: ts=3:sw=3:expandtab

### [line replaced by setup.py - do not delete]

import golem.app.main as app
from golem.util.tools import warning

if __name__ == "__main__":
   app.main()
